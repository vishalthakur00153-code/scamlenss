from app.engine import analyze_url
from app.rules.url_rules import inspect_url, normalize_url
def test_url_without_scheme(): assert normalize_url("example.com").startswith("https://")
def test_shortener_flagged(): assert any(f.rule=="url_shortener" for f in analyze_url("https://bit.ly/example").findings)
def test_paypal_official_domain_not_lookalike(): assert not any(f["rule"]=="brand_lookalike" for f in inspect_url("https://www.paypal.com"))
def test_ip_flagged(): assert any(f["rule"]=="raw_ip_host" for f in inspect_url("http://192.0.2.1/login"))
