from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
def test_health():
    r=client.get("/health"); assert r.status_code==200 and r.json()["status"]=="ok"
def test_homepage():
    r=client.get("/"); assert r.status_code==200 and "ScamLens" in r.text
def test_message_scan():
    r=client.post("/api/scan/message",json={"message":"Pay a refundable registration fee today to confirm your internship."})
    assert r.status_code==200 and r.json()["findings"]
def test_url_scan():
    r=client.post("/api/scan/url",json={"url":"http://bit.ly/example"})
    assert r.status_code==200 and r.json()["findings"]
def test_blank_message_rejected():
    assert client.post("/api/scan/message",json={"message":"   "}).status_code==422
