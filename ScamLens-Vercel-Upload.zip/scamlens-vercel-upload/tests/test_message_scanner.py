from app.engine import analyze_message
def test_upfront_fee_flagged():
    r=analyze_message("You are selected. Pay a refundable registration fee today.")
    assert any(f.rule=="upfront_fee" for f in r.findings) and r.score>=20
def test_otp_request_flagged():
    r=analyze_message("Your account is suspended. Share your OTP immediately.")
    assert r.findings
def test_normal_message_not_suspicious():
    assert analyze_message("Your class starts at 9 AM tomorrow.").risk_level=="Low Concern"
