from app.engine import analyze_message, analyze_url
def test_empty_message_engine(): assert analyze_message("").score==0
def test_whitespace_url_does_not_crash(): assert analyze_url("   ").risk_level in {"Low Concern","Needs Verification","Suspicious"}
def test_normal_message_not_suspicious(): assert analyze_message("Your class starts at 9 AM tomorrow.").risk_level=="Low Concern"
