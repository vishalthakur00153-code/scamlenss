# ScamLens

A transparent rule-based screening tool for suspicious messages, job/internship offers, and URLs.

## Features
- Message and URL checks with visible findings.
- Three risk levels: Low Concern, Needs Verification, Suspicious.
- FastAPI endpoints and responsive browser interface.
- Submitted URLs are parsed as text and are never visited by the scanner.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000. API documentation: /docs.

## API
- POST /api/scan/message with `{"message":"..."}`
- POST /api/scan/url with `{"url":"https://example.com"}`
- GET /health

## Deploy
Includes `vercel.json` and `api/index.py` for Vercel, and `render.yaml` for Render.

## Limitations
This is a heuristic demo, not a definitive fraud detector. It does not query live company, domain reputation, or law-enforcement databases. A low score does not establish that content is safe.
