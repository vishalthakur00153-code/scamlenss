from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from app.models import MessageScanRequest, UrlScanRequest, ScanResult
from app.engine import analyze_message, analyze_url
ROOT=Path(__file__).resolve().parents[1]
FRONTEND=ROOT/"frontend"
app=FastAPI(title="ScamLens API",version="1.0.0",description="Transparent rule-based message and URL screening.")
app.mount("/assets",StaticFiles(directory=str(FRONTEND)),name="assets")
@app.get("/",include_in_schema=False)
def home(): return FileResponse(FRONTEND/"index.html")
@app.get("/styles.css",include_in_schema=False)
def styles(): return FileResponse(FRONTEND/"styles.css",media_type="text/css")
@app.get("/app.js",include_in_schema=False)
def javascript(): return FileResponse(FRONTEND/"app.js",media_type="application/javascript")
@app.get("/health")
@app.get("/api/health")
def health(): return {"status":"ok","service":"ScamLens"}
@app.post("/api/scan/message",response_model=ScanResult)
def scan_message(request:MessageScanRequest): return analyze_message(request.message)
@app.post("/api/scan/url",response_model=ScanResult)
def scan_url(request:UrlScanRequest): return analyze_url(request.url)
