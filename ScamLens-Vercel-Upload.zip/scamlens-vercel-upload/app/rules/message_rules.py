import re
RULES = [
 ("upfront_fee", re.compile(r"\\b(registration fee|processing fee|training fee|pay (?:a |the )?fee|security deposit|refundable fee)\\b", re.I), "The message asks for an upfront fee or deposit.", "high", 35),
 ("urgency", re.compile(r"\\b(urgent|immediately|act now|last chance|limited time|within \\d+ hours)\\b", re.I), "The message uses pressure or urgency.", "medium", 12),
 ("guaranteed_reward", re.compile(r"\\b(guaranteed job|guaranteed income|lottery|jackpot|you have won|prize money)\\b", re.I), "The message promises unusually certain rewards.", "medium", 18),
 ("sensitive_info", re.compile(r"\\b(share your otp|send otp|password|bank details|card number|upi pin)\\b", re.I), "The message asks for sensitive credentials or financial details.", "high", 35),
 ("impersonation", re.compile(r"\\b(account suspended|police case|customs clearance|parcel held|official verification)\\b", re.I), "The message may impersonate an authority or service.", "medium", 15),
 ("private_channel", re.compile(r"\\b(whatsapp|telegram|dm me privately)\\b", re.I), "The sender directs the conversation to a private channel.", "low", 6),
]
def inspect_message(message):
    return [{"rule": n, "detail": d, "severity": s} for n,p,d,s,_ in RULES if p.search(message)]
def score_message(message):
    return min(100, sum(points for _,p,_,_,points in RULES if p.search(message)))
