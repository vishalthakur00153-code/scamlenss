import ipaddress, re
from urllib.parse import urlparse
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy"}
BRANDS = ("paypal", "google", "microsoft", "amazon", "instagram", "facebook", "apple", "netflix")
def normalize_url(value):
    value = value.strip()
    if value and not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", value):
        value = "https://" + value
    return value
def inspect_url(value):
    out=[]
    try:
        p=urlparse(normalize_url(value)); host=(p.hostname or "").lower().rstrip(".")
        if not host or ("." not in host and host != "localhost"):
            return [{"rule":"invalid_url","detail":"The URL has no recognizable hostname.","severity":"medium"}]
        try:
            ipaddress.ip_address(host.strip("[]"))
            out.append({"rule":"raw_ip_host","detail":"The link uses an IP address instead of a recognizable domain.","severity":"high"})
        except ValueError: pass
        if p.username or p.password:
            out.append({"rule":"embedded_credentials","detail":"The URL contains embedded login credentials.","severity":"high"})
        if host in SHORTENERS:
            out.append({"rule":"url_shortener","detail":"A URL shortener hides the final destination.","severity":"medium"})
        if host.startswith("xn--") or ".xn--" in host:
            out.append({"rule":"punycode","detail":"The domain uses punycode, which can disguise look-alike characters.","severity":"medium"})
        if len(host.split(".")) >= 5:
            out.append({"rule":"excessive_subdomains","detail":"The hostname has many subdomains.","severity":"medium"})
        for brand in BRANDS:
            if brand in host and host != brand+".com" and not host.endswith("."+brand+".com"):
                out.append({"rule":"brand_lookalike","detail":f"The hostname contains '{brand}' but is not an obvious official domain.","severity":"high"})
                break
        if p.scheme.lower() != "https":
            out.append({"rule":"no_https","detail":"The URL does not use HTTPS.","severity":"low"})
    except Exception:
        out.append({"rule":"invalid_url","detail":"The URL could not be parsed safely.","severity":"medium"})
    return out
def score_url(value):
    pts={"high":35,"medium":15,"low":5}
    return min(100,sum(pts.get(x["severity"],0) for x in inspect_url(value)))
