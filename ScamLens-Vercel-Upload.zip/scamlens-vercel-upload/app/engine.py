from app.models import Finding, ScanResult
from app.rules.message_rules import inspect_message, score_message
from app.rules.url_rules import inspect_url, score_url
NEXT_STEPS = [
 "Do not pay fees or deposits until the offer is independently verified.",
 "Contact the organization using contact details from its official website.",
 "Never share OTPs, passwords, UPI PINs, or banking credentials.",
 "Keep evidence and report suspected fraud through the appropriate official channel."
]
def _level(score):
    return "Suspicious" if score >= 50 else "Needs Verification" if score >= 20 else "Low Concern"
def analyze_message(message):
    score=score_message(message); findings=inspect_message(message)
    summary="Several strong warning signs were found." if score>=50 else "Some warning signs need independent verification." if score>=20 else "Few warning signs matched. This does not guarantee safety."
    return ScanResult(risk_level=_level(score),score=score,summary=summary,findings=[Finding(**x) for x in findings],next_steps=NEXT_STEPS)
def analyze_url(url):
    score=score_url(url); findings=inspect_url(url)
    summary="The URL has multiple warning signs." if score>=50 else "Verify the domain before interacting." if score>=20 else "Few URL warning signs matched. This does not guarantee safety."
    return ScanResult(risk_level=_level(score),score=score,summary=summary,findings=[Finding(**x) for x in findings],next_steps=NEXT_STEPS)
