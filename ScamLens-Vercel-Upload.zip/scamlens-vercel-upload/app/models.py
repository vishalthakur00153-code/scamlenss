from typing import Literal
from pydantic import BaseModel, Field, field_validator

class MessageScanRequest(BaseModel):
    message: str = Field(min_length=1, max_length=10000)
    @field_validator("message")
    @classmethod
    def not_blank(cls, value):
        if not value.strip():
            raise ValueError("Message cannot be blank.")
        return value.strip()

class UrlScanRequest(BaseModel):
    url: str = Field(min_length=1, max_length=2048)
    @field_validator("url")
    @classmethod
    def not_blank(cls, value):
        if not value.strip():
            raise ValueError("URL cannot be blank.")
        return value.strip()

class Finding(BaseModel):
    rule: str
    detail: str
    severity: Literal["low", "medium", "high"]

class ScanResult(BaseModel):
    risk_level: Literal["Low Concern", "Needs Verification", "Suspicious"]
    score: int = Field(ge=0, le=100)
    summary: str
    findings: list[Finding]
    next_steps: list[str]
    disclaimer: str = "ScamLens is a screening aid, not proof that a message or website is fraudulent."
